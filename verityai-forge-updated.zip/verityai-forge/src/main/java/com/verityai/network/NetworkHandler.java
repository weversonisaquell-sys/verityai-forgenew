package com.verityai.network;

import com.verityai.VerityAIMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * Canal de rede simples: usado só pra avisar o servidor "a Verity quer
 * dropar um item" quando o cliente detecta a tag [ITEM:...] na resposta
 * da IA. Dar itens de verdade só pode acontecer no servidor (autoridade
 * do jogo), por isso precisa desse pacote em vez de fazer direto no chat,
 * que roda no cliente.
 */
public class NetworkHandler {
    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VerityAIMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int nextId = 0;

    public static void register() {
        CHANNEL.registerMessage(nextId++, GiveItemPacket.class,
                GiveItemPacket::encode, GiveItemPacket::decode, GiveItemPacket::handle);
        CHANNEL.registerMessage(nextId++, TalkPingPacket.class,
                TalkPingPacket::encode, TalkPingPacket::decode, TalkPingPacket::handle);
    }
}
