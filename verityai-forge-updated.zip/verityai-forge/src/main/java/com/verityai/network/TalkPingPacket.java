package com.verityai.network;

import com.verityai.entity.VerityEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.function.Supplier;

/**
 * Pacote cliente -> servidor: "acabei de conversar de verdade com a
 * Verity" (chat digitado, painel ou voz - qualquer resposta que ela deu).
 * O servidor usa isso pra resetar o timer de "fome de conversa" da
 * Verity mais próxima, evitando que ela perca vida por negligência.
 */
public class TalkPingPacket {

    public TalkPingPacket() {}

    public static void encode(TalkPingPacket msg, FriendlyByteBuf buf) {
        // sem dados extras - só o envio já é a informação
    }

    public static TalkPingPacket decode(FriendlyByteBuf buf) {
        return new TalkPingPacket();
    }

    public static void handle(TalkPingPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;

            List<VerityEntity> nearby = player.level().getEntitiesOfClass(VerityEntity.class,
                    player.getBoundingBox().inflate(32.0));
            for (VerityEntity verity : nearby) {
                verity.resetTalkTimer();
            }
        });
        ctx.setPacketHandled(true);
    }
}
