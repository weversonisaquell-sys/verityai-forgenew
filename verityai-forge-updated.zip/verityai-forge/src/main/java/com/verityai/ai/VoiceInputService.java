package com.verityai.ai;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Grava áudio do microfone e manda transcrever pela API Whisper da Groq.
 *
 * IMPORTANTE: captura de microfone via Java (javax.sound.sampled) pode não
 * funcionar em todo ambiente Android/PojavLauncher - depende de como o
 * runtime Java foi empacotado ali. Por isso startRecording() retorna
 * false se o microfone não estiver disponível, e quem chama deve tratar
 * isso caindo de volta pro chat por texto (ver ClientForgeEvents).
 */
public class VoiceInputService {
    public static final VoiceInputService INSTANCE = new VoiceInputService();

    private static final String TRANSCRIBE_ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions";
    private static final String STT_MODEL = "whisper-large-v3-turbo";
    private static final AudioFormat FORMAT = new AudioFormat(16000f, 16, 1, true, false);
    private static final long MAX_RECORD_MS = 15000; // trava de segurança

    private volatile boolean recording = false;
    private TargetDataLine line;
    private Thread captureThread;
    private ByteArrayOutputStream buffer;

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .version(HttpClient.Version.HTTP_1_1) // evita "EOF reached" em ambientes tipo PojavLauncher
            .build();

    public boolean isRecording() {
        return recording;
    }

    /** @return true se conseguiu abrir o microfone e começar a gravar */
    public synchronized boolean startRecording() {
        if (recording) return true;
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
            if (!AudioSystem.isLineSupported(info)) {
                return false;
            }
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(FORMAT);
            line.start();
            buffer = new ByteArrayOutputStream();
            recording = true;

            captureThread = new Thread(() -> {
                byte[] chunk = new byte[4096];
                long start = System.currentTimeMillis();
                while (recording && System.currentTimeMillis() - start < MAX_RECORD_MS) {
                    int read = line.read(chunk, 0, chunk.length);
                    if (read > 0) buffer.write(chunk, 0, read);
                }
                if (recording) {
                    stopRecordingInternal(); // estourou o tempo máximo, encerra sozinho
                }
            }, "verityai-mic-capture");
            captureThread.setDaemon(true);
            captureThread.start();
            return true;
        } catch (Exception e) {
            VerityAIMod.LOGGER.warn("Microfone indisponível neste ambiente", e);
            recording = false;
            return false;
        }
    }

    /** Para a gravação e manda transcrever. onResult recebe o texto reconhecido. */
    public void stopAndTranscribeAsync(Consumer<String> onResult, Consumer<String> onError) {
        byte[] pcm = stopRecordingInternal();
        if (pcm == null || pcm.length < 4000) {
            onError.accept("audio_vazio");
            return;
        }

        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            onError.accept("no_key");
            return;
        }

        byte[] wav;
        try {
            wav = pcmToWav(pcm);
        } catch (Exception e) {
            onError.accept("erro_audio");
            return;
        }

        CompletableFuture.supplyAsync(() -> {
            try {
                return transcribe(wav, apiKey);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((text, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao transcrever áudio", throwable);
                onError.accept(throwable.getCause() != null ? throwable.getCause().getMessage() : throwable.getMessage());
            } else if (text == null || text.isBlank()) {
                onError.accept("audio_vazio");
            } else {
                onResult.accept(text.trim());
            }
        });
    }

    private synchronized byte[] stopRecordingInternal() {
        if (!recording) return null;
        recording = false;
        try {
            if (line != null) {
                line.stop();
                line.close();
            }
        } catch (Exception ignored) {
        }
        try {
            if (captureThread != null) captureThread.join(2000);
        } catch (InterruptedException ignored) {
        }
        return buffer != null ? buffer.toByteArray() : null;
    }

    private String transcribe(byte[] wavBytes, String apiKey) throws IOException, InterruptedException {
        String boundary = "----VerityAIBoundary" + System.currentTimeMillis();
        byte[] body = buildMultipartBody(boundary, wavBytes);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TRANSCRIBE_ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(body))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() / 100 != 2) {
            throw new RuntimeException("HTTP " + response.statusCode() + ": " + response.body());
        }
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        return json.has("text") ? json.get("text").getAsString() : null;
    }

    private byte[] buildMultipartBody(String boundary, byte[] wavBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String crlf = "\r\n";

        writeField(out, boundary, "model", STT_MODEL, crlf);
        writeField(out, boundary, "language", "pt", crlf);

        out.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"" + crlf)
                .getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Type: audio/wav" + crlf + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(wavBytes);
        out.write(crlf.getBytes(StandardCharsets.UTF_8));

        out.write(("--" + boundary + "--" + crlf).getBytes(StandardCharsets.UTF_8));
        return out.toByteArray();
    }

    private void writeField(ByteArrayOutputStream out, String boundary, String name, String value, String crlf)
            throws IOException {
        out.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"" + name + "\"" + crlf + crlf)
                .getBytes(StandardCharsets.UTF_8));
        out.write((value + crlf).getBytes(StandardCharsets.UTF_8));
    }

    private byte[] pcmToWav(byte[] pcmData) throws IOException {
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        try (AudioInputStream ais = new AudioInputStream(
                new ByteArrayInputStream(pcmData), FORMAT, pcmData.length / FORMAT.getFrameSize())) {
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, byteOut);
        }
        return byteOut.toByteArray();
    }
}
