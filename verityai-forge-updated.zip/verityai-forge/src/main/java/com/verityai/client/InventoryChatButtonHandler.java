package com.verityai.client;

import com.verityai.VerityAIMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Adiciona um botãozinho "Verity" na tela de inventário do jogador, pra
 * dar pra conversar com ela sem precisar sair procurando ela no mundo.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class InventoryChatButtonHandler {

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        int buttonX = (screen.width / 2) + 100;
        int buttonY = (screen.height / 2) - 80;

        event.addListener(Button.builder(Component.literal("§d💬 Verity"), button -> {
                    Minecraft mc = Minecraft.getInstance();
                    mc.setScreen(null);
                    ClientForgeEvents.openChatScreenClientSide();
                })
                .bounds(buttonX, buttonY, 70, 20)
                .build());
    }
}
