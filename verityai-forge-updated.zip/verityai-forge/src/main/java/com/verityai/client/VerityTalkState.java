package com.verityai.client;

/**
 * Guarda, do lado do cliente, quando foi a última vez que a Verity falou
 * no chat e por quanto tempo a "fala" (bolha/expressão) deve continuar
 * ativa. É atualizado no único ponto em que o mod detecta que a Verity
 * falou no chat (junto com o disparo do áudio em VerityVoiceService), e
 * lido pelo BoxHudOverlay pra escolher a textura do rosto (neutral,
 * neutral_talking, happy, happy_talking, angry).
 */
public final class VerityTalkState {

    /** Depois de 2 minutos sem a Verity falar, o rosto volta pra neutral. */
    private static final long IDLE_MILLIS = 2 * 60 * 1000L;

    /** Tempo mínimo/máximo que a expressão "falando" fica ativa por mensagem. */
    private static final long MIN_TALK_MILLIS = 1500L;
    private static final long MAX_TALK_MILLIS = 8000L;
    private static final long MILLIS_PER_CHAR = 55L;

    private static volatile long lastTalkMillis = System.currentTimeMillis();
    private static volatile long talkingUntilMillis = 0L;

    private VerityTalkState() {
    }

    /**
     * Chame sempre que o mod detectar que a Verity falou no chat
     * (mensagem "[Verity] ..." adicionada), pra reiniciar o contador de
     * inatividade e ligar a expressão de "falando" por um tempo
     * proporcional ao tamanho do texto.
     */
    public static void onVerityMessage(String text) {
        long now = System.currentTimeMillis();
        lastTalkMillis = now;

        int length = text == null ? 0 : text.length();
        long duration = Math.max(MIN_TALK_MILLIS, Math.min(MAX_TALK_MILLIS, length * MILLIS_PER_CHAR));
        talkingUntilMillis = now + duration;
    }

    /** true enquanto a expressão de "falando" deve estar ativa. */
    public static boolean isTalkingNow() {
        return System.currentTimeMillis() < talkingUntilMillis;
    }

    /** true quando já passaram 2 minutos (ou mais) desde a última fala da Verity. */
    public static boolean isIdleTooLong() {
        return System.currentTimeMillis() - lastTalkMillis >= IDLE_MILLIS;
    }
}
