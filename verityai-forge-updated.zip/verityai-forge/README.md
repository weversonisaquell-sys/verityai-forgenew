# Verity AI — Mod Forge para 1.20.1

Mod que adiciona uma entidade "Verity" no mundo (uma bolinha flutuante).
Aperte **V** (ou clique com botão direito nela, ou digite `Verity <msg>`
no chat) pra conversar com ela usando a IA da Groq (modelos Llama,
gratuita e sem cartão de crédito).

⚠️ **Importante:** eu escrevi todo o código, mas não consegui compilar o
`.jar` aqui porque meu ambiente não tem acesso à internet (o Forge precisa
baixar o MDK e as bibliotecas via Gradle). Você vai precisar compilar num PC
uma vez — depois é só copiar o `.jar` pronto pro celular. Veja o passo a
passo abaixo.

---

## 1. Compilar o mod (sem PC, 100% pelo celular, via GitHub Actions)

O GitHub oferece build na nuvem de graça (GitHub Actions). Este projeto já
vem com o arquivo de configuração pronto (`.github/workflows/build.yml`) -
você só precisa colocar o código lá.

### Passo 1 — Instalar o Termux (terminal Linux pro Android)

Baixe o Termux pela **F-Droid** (não pela Play Store, a versão de lá está
desatualizada e quebrada): https://f-droid.org/packages/com.termux/

### Passo 2 — Instalar git no Termux

Abra o Termux e rode:

```bash
termux-setup-storage
pkg update -y
pkg install -y git unzip
```

(no `termux-setup-storage`, aceite a permissão que o Android pedir — é o
que permite o Termux enxergar sua pasta de Downloads)

### Passo 3 — Criar conta e repositório no GitHub

1. Crie uma conta grátis em **github.com** (pelo navegador do celular)
2. Clique em **"New repository"**, nome `verityai-forge`, deixe
   **Public** ou **Private** (tanto faz), **não** marque "Add a README"
3. Depois de criar, copie a URL que aparece, tipo:
   `https://github.com/SEU_USUARIO/verityai-forge.git`

### Passo 4 — Gerar um token de acesso

O GitHub não aceita mais senha normal pra enviar código, precisa de um
token:

1. No navegador: **Settings > Developer settings > Personal access
   tokens > Tokens (classic) > Generate new token (classic)**
2. Marque a permissão **`repo`**, gere, e **copie o token** (só aparece
   uma vez — guarde num lugar seguro, tipo um app de notas privado)

### Passo 5 — Enviar o código pelo Termux

Baixe o `verityai-forge.zip` que te mandei aqui no chat (vai pra pasta
Downloads do celular). Depois, no Termux:

```bash
cd ~/storage/downloads
unzip verityai-forge.zip
cd verityai-forge
git init
git add .
git commit -m "primeira versao do mod"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/verityai-forge.git
git push -u origin main
```

Quando pedir usuário e senha: usuário é seu usuário do GitHub, e a
"senha" é o **token** que você gerou no passo 4 (não sua senha normal).

### Passo 6 — Acompanhar o build e baixar o .jar

1. No navegador, vá em `github.com/SEU_USUARIO/verityai-forge/actions`
2. Vai aparecer um build rodando (bolinha amarela) — espera terminar
   (fica verde ✅, leva uns 2-5 minutos)
3. Clica em cima do build concluído, desce até **"Artifacts"**
4. Baixa o arquivo `verityai-jar` (é um `.zip` que contém o `.jar` de
   verdade dentro)
5. Extrai esse zip (o gerenciador de arquivos do Android abre zip
   normalmente) — dentro vai estar o `verityai-1.0.0.jar`

Esse `.jar` é o arquivo final que vai pra pasta `mods` do PojavLauncher.

> Se algum dia você mudar algum código do mod (ex: eu te mandar um
> arquivo atualizado), o processo pra recompilar é só repetir o Passo 5
> (`git add .`, `git commit`, `git push`) — o GitHub recompila sozinho de
> novo.

---

## (Alternativa) Compilar com PC

Se em algum momento você tiver acesso a um PC, também dá pra compilar
direto por lá:

Pré-requisitos:
- **Java 17** instalado ([Adoptium/Temurin 17](https://adoptium.net/temurin/releases/?version=17))
- Este projeto (a pasta `verityai-forge`)

Passos:

```bash
cd verityai-forge

# Linux/Mac:
./gradlew build

# Windows (PowerShell/CMD):
gradlew.bat build
```

A primeira execução demora (baixa o Forge, mapeamentos, etc — só funciona
com internet). Se der tudo certo, o `.jar` final aparece em:

```
build/libs/verityai-1.0.0.jar
```

> Se aparecer erro de "gradlew: Permission denied" no Linux/Mac, rode antes:
> `chmod +x gradlew`
>
> Se faltar o `gradlew`/`gradlew.bat` (não incluí os binários do wrapper),
> rode `gradle wrapper --gradle-version 8.1` uma vez (com Gradle instalado)
> antes do `./gradlew build`.

## 2. Pegar a API key da Groq (grátis, sem cartão)

1. Acesse **https://console.groq.com/keys**
2. Faça login (dá pra usar sua conta Google)
3. Clique em **"Create API Key"**
4. Copie a chave (algo como `gsk_...`)

## 3. Instalar no PojavLauncher (celular)

⚠️ **Passo extra obrigatório:** o mod usa a biblioteca **GeckoLib** (pra
animar a "Caixinha" 3D) - ela não vem dentro do seu `.jar`, precisa
instalar como **outro mod separado**, senão o jogo trava ao abrir:

1. Baixe `geckolib-forge-1.20.1-4.4.7.jar` em
   **modrinth.com/mod/geckolib/version/rF4Es4hd**
2. Coloque esse `.jar` também na pasta `mods/` (junto com o seu)

Feito isso:

1. Copie `verityai-1.0.0.jar` (do passo 1) para o celular
2. No PojavLauncher, use um perfil com **Forge 1.20.1** já instalado
3. Coloque o `.jar` do mod (e o do GeckoLib) na pasta `.minecraft/mods/`
   (crie a pasta `mods` se não existir, dentro da pasta do jogo do
   PojavLauncher)
4. Abra o jogo com o perfil Forge 1.20.1

## 4. Configurar a API key dentro do jogo

Dentro de um mundo, abra o chat normal do Minecraft e digite:

```
/verityai key SUA_KEY_AQUI
```

Isso salva a chave em `config/verityai-client.toml` (fica só no seu
aparelho). Depois disso você pode conversar de duas formas:

- Apertando **V** (abre uma telinha dedicada de chat), ou dando clique
  direito na Verity
- Digitando `Verity sua mensagem` (ou `Verity: sua mensagem`) direto no
  chat normal do Minecraft — a mensagem não é enviada pro mundo/servidor,
  ela vai direto pra IA e a resposta aparece no próprio chat, tipo:

  ```
  Verity onde eu deveria construir minha base?
  [Verity] Nas sombras de uma caverna, longe da luz que revela...
  ```

## 5. Colocar a Verity no mundo

Agora tem duas formas:

- **Pelo inventário (mais fácil):** no modo Criativo, abre o inventário e
  procura a aba própria do mod (ícone do ovo amarelo/preto, geralmente a
  última aba à direita) — lá tem o **"Ovo de Spawn da Verity"**. É só
  pegar e usar (clicar) no chão que ela aparece, igual qualquer ovo de
  spawn vanilla (de galinha, vaca, etc)
- **Por comando** (funciona em qualquer modo, precisa de cheats ativados):
  ```
  /summon verityai:verity
  ```

## 6. Sobre o formato redondo

A Verity agora é desenhada como uma **esfera de verdade**, gerada
matematicamente dentro do código (`client/render/VerityRenderer.java`) —
não é mais um cubo do Blockbench. Isso porque o formato padrão de
entidades do Minecraft/Forge só suporta caixas retas; pra ficar realmente
redondo, a forma é montada direto em Java, sem depender do Blockbench.

A textura (`assets/verityai/textures/entity/verity.png`) usa mapeamento
**equiretangular** (tipo um mapa-múndi: largura = "dar a volta" na bola,
altura = de polo a polo). Se quiser trocar a textura por uma sua, mantém
esse formato — pode editar a imagem 64x32 num editor comum (não precisa
do Blockbench pra isso).

Se no futuro você quiser adicionar detalhes 3D extras (tipo um chapéu, um
acessório, olhos "para fora" da bola), aí sim o Blockbench (formato
**Modded Entity**) entra em jogo — é só me mandar o `.java` exportado que
eu integro como uma peça extra por cima da esfera.

## 7. Pedir itens pra Verity

Agora dá pra pedir itens de verdade na conversa, tipo:

```
Verity me dá um diamante
[Verity] Ah, um pedaço de estrela cristalizada... aqui está. *solta um diamante*
```

Ela entende o pedido e solta o item no chão perto dela (ou perto de você,
se não tiver nenhuma Verity por perto). Funciona tanto pela tecla V quanto
digitando `Verity <pedido>` no chat. A IA decide quais itens dar com base
no que você pediu — funciona melhor com itens comuns do Minecraft (ex:
diamante, maçã, pão, tocha, lingote de ferro). Como é a IA quem decide,
às vezes ela pode não entender um pedido muito específico ou incomum.

## 8. Voo, lanterna, escuridão, voz e captura

- **Rola no chão te seguindo:** a Verity anda com gravidade normal (não
  voa) e fica rolando pelo chão na sua direção quando você se afasta,
  tipo um bichinho de estimação - a esfera gira de verdade proporcional à
  distância percorrida.
- **Tecla V = segurar pra falar por voz:** segure V, fale, solte - o mod
  grava o áudio e manda transcrever pela Whisper da Groq. **Isso é
  experimental**: depende do PojavLauncher conseguir acessar o microfone
  via Java, o que nem sempre funciona em todo aparelho Android. Se não
  rolar, o mod detecta sozinho e abre o painel de texto de sempre - nada
  quebra, só não vai ter a parte de voz.
- **Ela fala em voz alta:** as respostas (por voz ou por texto) tocam em
  áudio (voz feminina, via API da Groq). Limitação real: essa API só tem
  vozes em inglês/árabe, então o português sai com sotaque estrangeiro.
  Se o áudio não tocar no seu aparelho, o texto no chat continua
  funcionando normalmente.
- **Lanterna (`Lanterna da Verity`):** clique direito liga/desliga.
  Ligada, dá visão no escuro e cancela a escuridão pesada da noite. Tem
  modelo 3D de verdade (não é mais ícone plano) e aparece na mão.
- **Escuridão pesada à noite:** sem a lanterna ligada, a tela escurece
  bastante durante a noite, parecido com o jogo original. Ao amanhecer,
  volta ao normal.
- **Capturar a Verity:** Shift + clique nela guarda ela numa "Bola da
  Verity" no seu inventário (ela desaparece do mundo). Usar a bola num
  bloco solta ela de novo. Clique normal (sem Shift) continua abrindo o
  chat de texto.
- **Itens 3D de verdade no inventário/mão:** tanto o ovo de spawn quanto a
  bola capturada aparecem como a mesma esfera 3D da entidade (não é mais
  ícone chapado), reaproveitando o mesmo desenho.

## 9. Botão no inventário e "fome de conversa"

- **Botão no inventário:** abra o inventário normal (tecla de inventário)
  e vai ter um botãozinho **"💬 Verity"** no canto - clica nele pra abrir
  o chat direto, sem precisar sair procurando ela no mundo.
- **Ela sente sua falta:** se você ficar **1 minuto sem conversar** com
  ela (por chat, voz ou pelo painel/inventário), ela perde 2 pontos de
  vida (1 coração). Isso se repete a cada minuto de silêncio, mas ela
  nunca morre só por negligência (para num mínimo de 1 coração). Só voltar
  a falar com ela reseta o contador.

## Estrutura do projeto

```
src/main/java/com/verityai/
├── VerityAIMod.java          # classe principal, registra tudo
├── VerityCommands.java       # /verityai key <chave>
├── entity/
│   ├── ModEntities.java      # registro do EntityType
│   └── VerityEntity.java     # comportamento (andar, olhar, interagir)
├── item/
│   ├── ModItems.java         # ovo de spawn da Verity
│   └── ModCreativeTabs.java  # aba própria no menu Criativo
├── network/
│   ├── NetworkHandler.java   # canal de rede do mod
│   └── GiveItemPacket.java   # cliente pede, servidor solta o item
├── client/
│   ├── KeyBindings.java      # tecla V
│   ├── ClientForgeEvents.java# detecta a tecla V, o chat digitado, e abre a tela
│   ├── render/
│   │   └── VerityRenderer.java # desenha a esfera (procedural, sem Blockbench)
│   └── gui/
│       └── VerityChatScreen.java # tela de chat
├── ai/
│   ├── GroqService.java      # chamada HTTP assíncrona pra API da Groq
│   └── ItemRequestParser.java# acha a tag [ITEM:...] na resposta da IA
└── config/
    └── VerityConfig.java     # onde a API key fica salva
```

## Limitações conhecidas / próximos passos

- Sem animações (o modelo é estático, só anda e olha pro jogador)
- Sem spawn natural (só via ovo de spawn ou `/summon`)
- Histórico de conversa é só em memória (reseta ao fechar o jogo)
- O modelo visual é um placeholder — troque pelo seu do Blockbench
