package com.verityai.ai;

import com.verityai.network.GiveItemPacket;
import com.verityai.network.NetworkHandler;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A IA é instruída (no system prompt) a incluir uma tag tipo
 * "[ITEM:minecraft:diamond:3]" no fim da resposta quando o jogador pede um
 * item. Essa classe acha essa tag, manda o pedido pro servidor soltar o
 * item de verdade, e devolve o texto SEM a tag (pra não aparecer feio no
 * chat).
 */
public class ItemRequestParser {
    private static final Pattern TAG_PATTERN =
            Pattern.compile("\\[ITEM:([a-zA-Z0-9_.\\-]+:[a-zA-Z0-9_.\\-]+):(\\d+)\\]");

    public static String process(String rawResponse) {
        if (rawResponse == null || rawResponse.isEmpty()) return rawResponse;

        Matcher matcher = TAG_PATTERN.matcher(rawResponse);
        while (matcher.find()) {
            String itemId = matcher.group(1);
            int count;
            try {
                count = Integer.parseInt(matcher.group(2));
            } catch (NumberFormatException e) {
                count = 1;
            }
            NetworkHandler.CHANNEL.sendToServer(new GiveItemPacket(itemId, count));
        }

        return matcher.replaceAll("").trim().replaceAll("\\s{2,}", " ");
    }
}
