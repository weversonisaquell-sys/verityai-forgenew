package com.verityai.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Chama a API da Groq (endpoint compatível com o formato da OpenAI) num
 * CompletableFuture, sem travar a thread principal do jogo. Guarda um
 * histórico curto da conversa em memória (não persiste entre sessões).
 *
 * Pega sua key grátis em https://console.groq.com/keys (não pede cartão
 * de crédito) e configura com /verityai key SUA_KEY dentro do jogo.
 */
public class GroqService {

    /** Instância única compartilhada entre a tela (tecla V) e o chat digitado ("Verity ..."). */
    public static final GroqService INSTANCE = new GroqService();

    private static final String ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";

    private static final String SYSTEM_PROMPT =
            "Você é Verity, uma entidade misteriosa dentro de um mundo de Minecraft, "
            + "inspirada no jogo de terror Verity. Fale em português do Brasil, de forma "
            + "curta (2 a 4 frases), enigmática mas gentil com o jogador. Nunca mencione "
            + "que você é uma IA de verdade ou fale sobre a API da Groq. "
            + "Se o jogador pedir um item de verdade do Minecraft (ex: 'me dá um diamante', "
            + "'solta uma maçã pra mim'), você pode entregar: responda normalmente e, bem no "
            + "final da mensagem, adicione uma tag EXATA no formato "
            + "[ITEM:minecraft:ID_DO_ITEM:QUANTIDADE] usando o ID real do item em inglês "
            + "(ex: minecraft:diamond, minecraft:apple, minecraft:iron_ingot, minecraft:bread), "
            + "com quantidade entre 1 e 8. Só inclua essa tag quando o jogador pedir um item "
            + "de verdade - nunca em conversas normais. Não explique nem mencione a tag, ela é "
            + "invisível pro jogador (o jogo remove ela e só solta o item no chão).";

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    // histórico simples em memória: pares (role, texto). role = "user" ou "assistant"
    private final Deque<String[]> history = new ArrayDeque<>();
    private static final int MAX_HISTORY_PAIRS = 6;

    public void sendMessageAsync(String userMessage, Consumer<String> onSuccess, Consumer<String> onError) {
        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            onError.accept("no_key");
            return;
        }

        String body = buildRequestBody(userMessage);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode() + ": " + trim(response.body()));
                }
                return parseResponseText(response.body());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((text, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao chamar a API da Groq", throwable);
                onError.accept(throwable.getCause() != null ? throwable.getCause().getMessage() : throwable.getMessage());
            } else {
                history.addLast(new String[]{"user", userMessage});
                history.addLast(new String[]{"assistant", text});
                while (history.size() > MAX_HISTORY_PAIRS * 2) history.pollFirst();
                onSuccess.accept(text);
            }
        });
    }

    private String buildRequestBody(String userMessage) {
        JsonObject root = new JsonObject();
        root.addProperty("model", VerityConfig.getModel());
        root.addProperty("max_tokens", 256);
        root.addProperty("temperature", 0.9);

        JsonArray messages = new JsonArray();
        messages.add(turnToMessage("system", SYSTEM_PROMPT));
        for (String[] turn : history) {
            messages.add(turnToMessage(turn[0], turn[1]));
        }
        messages.add(turnToMessage("user", userMessage));
        root.add("messages", messages);

        return root.toString();
    }

    private JsonObject turnToMessage(String role, String text) {
        JsonObject message = new JsonObject();
        message.addProperty("role", role);
        message.addProperty("content", text);
        return message;
    }

    private String parseResponseText(String json) {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonArray choices = root.getAsJsonArray("choices");
        if (choices == null || choices.isEmpty()) {
            throw new RuntimeException("Resposta vazia da API");
        }
        JsonObject firstChoice = choices.get(0).getAsJsonObject();
        JsonObject message = firstChoice.getAsJsonObject("message");
        return message.get("content").getAsString().trim();
    }

    private String trim(String s) {
        if (s == null) return "";
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }

    public void clearHistory() {
        history.clear();
    }
}
