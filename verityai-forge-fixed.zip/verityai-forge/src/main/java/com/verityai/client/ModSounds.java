package com.verityai.client;

import com.verityai.VerityAIMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Sons usados pela caixinha da Verity (clique, abertura e as três falas
 * de voz que tocam enquanto ela "pensa" antes de abrir).
 */
public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, VerityAIMod.MOD_ID);

    public static final RegistryObject<SoundEvent> BOX_CLICK = register("box.click");
    public static final RegistryObject<SoundEvent> BOX_OPEN = register("box.open");
    public static final RegistryObject<SoundEvent> BOX_VERITY_0 = register("box.verity0");
    public static final RegistryObject<SoundEvent> BOX_VERITY_1 = register("box.verity1");
    public static final RegistryObject<SoundEvent> BOX_VERITY_2 = register("box.verity2");

    private static RegistryObject<SoundEvent> register(String name) {
        ResourceLocation id = new ResourceLocation(VerityAIMod.MOD_ID, name);
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
}
