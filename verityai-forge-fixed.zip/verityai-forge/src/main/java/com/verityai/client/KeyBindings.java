package com.verityai.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public class KeyBindings {
    public static final String CATEGORY = "key.categories.verityai";

    public static final KeyMapping TALK_KEY = new KeyMapping(
            "key.verityai.talk",
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_V,
            CATEGORY
    );
}
