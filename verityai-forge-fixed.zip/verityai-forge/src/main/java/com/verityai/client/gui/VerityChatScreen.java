package com.verityai.client.gui;

import com.verityai.ai.GroqService;
import com.verityai.ai.ItemRequestParser;
import com.verityai.ai.VerityVoiceService;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Tela simples de chat: caixa de texto embaixo + histórico de mensagens.
 * Aberta pela tecla V (ClientForgeEvents) ou clicando com o botão direito
 * na Verity (VerityEntity#mobInteract).
 */
public class VerityChatScreen extends Screen {

    private static final GroqService AI = GroqService.INSTANCE;

    private EditBox inputBox;
    private Button sendButton;
    private final List<Component> messages = new ArrayList<>();
    private boolean waitingForResponse = false;

    public VerityChatScreen() {
        super(Component.translatable("gui.verityai.chat.title"));
    }

    @Override
    protected void init() {
        int boxWidth = Math.min(320, this.width - 40);
        int inputY = this.height - 40;

        this.inputBox = new EditBox(this.font, (this.width - boxWidth) / 2, inputY, boxWidth - 60, 20,
                Component.translatable("gui.verityai.chat.placeholder"));
        this.inputBox.setMaxLength(500);
        this.inputBox.setHint(Component.translatable("gui.verityai.chat.placeholder"));
        this.addWidget(this.inputBox);
        this.setInitialFocus(this.inputBox);

        this.sendButton = Button.builder(Component.translatable("gui.verityai.chat.send"), b -> trySend())
                .bounds((this.width - boxWidth) / 2 + boxWidth - 55, inputY, 55, 20)
                .build();
        this.addRenderableWidget(this.sendButton);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter / Numpad Enter
            trySend();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void trySend() {
        if (waitingForResponse) return;
        String text = this.inputBox.getValue().trim();
        if (text.isEmpty()) return;

        messages.add(Component.literal("§b" + this.minecraft.player.getName().getString() + ": §f" + text));
        this.inputBox.setValue("");
        waitingForResponse = true;
        messages.add(Component.translatable("gui.verityai.chat.thinking").withStyle(s -> s.withItalic(true)));

        AI.sendMessageAsync(text,
                response -> this.minecraft.execute(() -> {
                    removeLastMessage();
                    String cleanText = ItemRequestParser.process(response);
                    messages.add(Component.literal("§d Verity: §f" + cleanText));
                    waitingForResponse = false;
                    if (this.minecraft.player != null) {
                        this.minecraft.player.sendSystemMessage(Component.literal("§d[Verity] §f" + cleanText));
                    }
                    VerityVoiceService.INSTANCE.speakAsync(cleanText);
                }),
                error -> this.minecraft.execute(() -> {
                    removeLastMessage();
                    if ("no_key".equals(error)) {
                        messages.add(Component.translatable("gui.verityai.chat.no_key"));
                    } else {
                        messages.add(Component.translatable("gui.verityai.chat.error", error));
                    }
                    waitingForResponse = false;
                })
        );
    }

    private void removeLastMessage() {
        if (!messages.isEmpty()) messages.remove(messages.size() - 1);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);

        int boxWidth = Math.min(320, this.width - 40);
        int left = (this.width - boxWidth) / 2;

        graphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);

        int y = 40;
        int maxLines = (this.height - 90) / 12;
        int start = Math.max(0, messages.size() - maxLines);
        for (int i = start; i < messages.size(); i++) {
            graphics.drawWordWrap(this.font, messages.get(i), left, y, boxWidth, 0xFFFFFF);
            y += 12;
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
