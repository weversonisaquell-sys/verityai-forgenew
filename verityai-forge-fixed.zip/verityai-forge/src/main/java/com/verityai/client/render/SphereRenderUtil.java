package com.verityai.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Desenha uma esfera (mapeamento de textura equiretangular, tipo mapa-múndi)
 * direto em código - sem depender de nenhum modelo do Blockbench. Usado
 * tanto pra entidade (VerityRenderer) quanto pro ícone 3D dos itens
 * (ovo de spawn / orbe capturada), pra tudo ficar visualmente igual.
 */
public final class SphereRenderUtil {
    private SphereRenderUtil() {}

    public static void renderSphere(PoseStack poseStack, VertexConsumer consumer, int packedLight,
                                     float radius, int latSegments, int lonSegments) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f positionMatrix = pose.pose();
        Matrix3f normalMatrix = pose.normal();

        for (int lat = 0; lat < latSegments; lat++) {
            float theta1 = (float) (Math.PI * lat / latSegments);
            float theta2 = (float) (Math.PI * (lat + 1) / latSegments);
            float v1 = (float) lat / latSegments;
            float v2 = (float) (lat + 1) / latSegments;

            for (int lon = 0; lon < lonSegments; lon++) {
                float phi1 = (float) (2 * Math.PI * lon / lonSegments);
                float phi2 = (float) (2 * Math.PI * (lon + 1) / lonSegments);
                float u1 = (float) lon / lonSegments;
                float u2 = (float) (lon + 1) / lonSegments;

                float[] p1 = toCartesian(theta1, phi1, radius);
                float[] p2 = toCartesian(theta2, phi1, radius);
                float[] p3 = toCartesian(theta2, phi2, radius);
                float[] p4 = toCartesian(theta1, phi2, radius);

                vertex(consumer, positionMatrix, normalMatrix, p1, u1, v1, packedLight, radius);
                vertex(consumer, positionMatrix, normalMatrix, p2, u1, v2, packedLight, radius);
                vertex(consumer, positionMatrix, normalMatrix, p3, u2, v2, packedLight, radius);
                vertex(consumer, positionMatrix, normalMatrix, p4, u2, v1, packedLight, radius);
            }
        }
    }

    private static float[] toCartesian(float theta, float phi, float radius) {
        float x = radius * (float) (Math.sin(theta) * Math.cos(phi));
        float y = radius * (float) Math.cos(theta);
        float z = radius * (float) (Math.sin(theta) * Math.sin(phi));
        return new float[]{x, y, z};
    }

    private static void vertex(VertexConsumer consumer, Matrix4f positionMatrix, Matrix3f normalMatrix,
                                float[] p, float u, float v, int packedLight, float radius) {
        float nx = p[0] / radius;
        float ny = p[1] / radius;
        float nz = p[2] / radius;
        consumer.vertex(positionMatrix, p[0], p[1], p[2])
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(normalMatrix, nx, ny, nz)
                .endVertex();
    }
}
