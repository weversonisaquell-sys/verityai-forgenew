package com.verityai.client;

import com.verityai.entity.BoxEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class BoxRenderer extends GeoEntityRenderer<BoxEntity> {

    public BoxRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new BoxModel());
        this.shadowRadius = 0.4f;
    }

    @Override
    public boolean shouldShowName(BoxEntity animatable) {
        return false;
    }
}
