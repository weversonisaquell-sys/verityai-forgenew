package com.verityai.client;

import com.verityai.VerityAIMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Desenha a barra de alegria da Verity (igual à do mod original) fixa
 * no canto superior direito da tela, com um rostinho ao lado indicando
 * o humor atual. A caixinha em si é a entidade 3D (com GeckoLib) que
 * fica espalhada no mundo - ver BoxEntity/BoxModel/BoxRenderer.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class BoxHudOverlay {

    private static final ResourceLocation JOY_FULL_TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/gui/box/joy_full.png");
    private static final ResourceLocation JOY_EMPTY_TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/gui/box/joy_empty.png");
    private static final ResourceLocation HAPPY_TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/gui/box/happy.png");
    private static final ResourceLocation NEUTRAL_TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/gui/box/neutral.png");
    private static final ResourceLocation ANGRY_TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/gui/box/angry.png");

    private static final int MARGIN = 6;
    private static final int FACE_TEX_SIZE = 16;
    private static final int FACE_DRAW_SIZE = 14;
    private static final int JOY_BAR_WIDTH = 182; // mesma largura da textura original
    private static final int JOY_BAR_HEIGHT = 5;

    /** Alegria atual da caixa, de 0.0 (vazia) a 1.0 (cheia). */
    public static float joy = 1.0f;

    @SubscribeEvent
    public static void onRenderGuiPost(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (mc.options.hideGui) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int screenWidth = mc.getWindow().getGuiScaledWidth();

        int barX = screenWidth - MARGIN - JOY_BAR_WIDTH;
        int barY = MARGIN;

        drawFace(graphics, barX, barY);
        drawJoyBar(graphics, barX, barY);
    }

    private static void drawFace(GuiGraphics graphics, int barX, int barY) {
        ResourceLocation face;
        if (joy < 0.25f) {
            face = ANGRY_TEXTURE;
        } else if (joy < 0.6f) {
            face = NEUTRAL_TEXTURE;
        } else {
            face = HAPPY_TEXTURE;
        }

        int faceX = barX - FACE_DRAW_SIZE - 3;
        int faceY = barY - (FACE_DRAW_SIZE - JOY_BAR_HEIGHT) / 2;
        graphics.blit(face, faceX, faceY, FACE_DRAW_SIZE, FACE_DRAW_SIZE,
                0, 0, FACE_TEX_SIZE, FACE_TEX_SIZE, FACE_TEX_SIZE, FACE_TEX_SIZE);
    }

    private static void drawJoyBar(GuiGraphics graphics, int x, int y) {
        graphics.blit(JOY_EMPTY_TEXTURE, x, y, JOY_BAR_WIDTH, JOY_BAR_HEIGHT,
                0, 0, JOY_BAR_WIDTH, JOY_BAR_HEIGHT, JOY_BAR_WIDTH, JOY_BAR_HEIGHT);

        int filledWidth = Math.round(JOY_BAR_WIDTH * Math.max(0f, Math.min(1f, joy)));
        if (filledWidth <= 0) return;
        graphics.blit(JOY_FULL_TEXTURE, x, y, filledWidth, JOY_BAR_HEIGHT,
                0, 0, filledWidth, JOY_BAR_HEIGHT, JOY_BAR_WIDTH, JOY_BAR_HEIGHT);
    }
}
