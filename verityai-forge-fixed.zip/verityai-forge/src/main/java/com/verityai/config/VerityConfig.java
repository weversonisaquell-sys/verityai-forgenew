package com.verityai.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class VerityConfig {
    public static final ForgeConfigSpec CLIENT_SPEC;
    private static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    private static final ForgeConfigSpec.ConfigValue<String> MODEL;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("groq");
        API_KEY = builder
                .comment("Sua API key da Groq (crie gratis, sem cartao, em https://console.groq.com/keys)",
                         "Voce tambem pode setar com o comando /verityai key <SUA_KEY> dentro do jogo.")
                .define("apiKey", "");
        MODEL = builder
                .comment("Modelo da Groq usado para gerar as respostas.",
                         "Opcoes: llama-3.3-70b-versatile (melhor qualidade) ou",
                         "llama-3.1-8b-instant (mais rapido/leve, bom se bater limite de uso).")
                .define("model", "llama-3.3-70b-versatile");
        builder.pop();
        CLIENT_SPEC = builder.build();
    }

    // permite setar em runtime via comando, sem precisar reiniciar o jogo
    private static String runtimeApiKeyOverride = null;

    public static String getApiKey() {
        if (runtimeApiKeyOverride != null && !runtimeApiKeyOverride.isBlank()) {
            return runtimeApiKeyOverride;
        }
        return API_KEY.get();
    }

    public static void setApiKey(String key) {
        runtimeApiKeyOverride = key;
        API_KEY.set(key);
        API_KEY.save();
    }

    public static String getModel() {
        String m = MODEL.get();
        return (m == null || m.isBlank()) ? "llama-3.3-70b-versatile" : m;
    }
}
