package com.verityai.entity;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Faz a Verity rolar (no chão, com gravidade normal) atrás do jogador
 * mais próximo, tipo um bichinho de estimação. Mantém uma distância curta
 * em vez de grudar em cima do jogador.
 */
public class FloatFollowPlayerGoal extends Goal {
    private final VerityEntity verity;
    private final double followRange;
    private final double stopDistance;
    private Player targetPlayer;

    public FloatFollowPlayerGoal(VerityEntity verity, double followRange, double stopDistance) {
        this.verity = verity;
        this.followRange = followRange;
        this.stopDistance = stopDistance;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        Player nearest = verity.level().getNearestPlayer(verity, followRange);
        if (nearest == null || nearest.isSpectator() || nearest.isCreative() && nearest.isSpectator()) {
            return false;
        }
        this.targetPlayer = nearest;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return targetPlayer != null && targetPlayer.isAlive()
                && !targetPlayer.isSpectator()
                && verity.distanceToSqr(targetPlayer) <= (followRange * 1.5) * (followRange * 1.5);
    }

    @Override
    public void stop() {
        this.targetPlayer = null;
    }

    @Override
    public void tick() {
        if (targetPlayer == null) return;

        verity.getLookControl().setLookAt(targetPlayer, 30.0F, 30.0F);

        double distSq = verity.distanceToSqr(targetPlayer);
        if (distSq > stopDistance * stopDistance) {
            Vec3 target = targetPlayer.position();
            verity.getNavigation().moveTo(target.x, target.y, target.z, 0.9);
        }
    }
}
