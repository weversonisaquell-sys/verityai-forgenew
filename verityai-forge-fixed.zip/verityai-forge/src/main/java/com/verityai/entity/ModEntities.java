package com.verityai.entity;

import com.verityai.VerityAIMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, VerityAIMod.MOD_ID);

    public static final RegistryObject<EntityType<VerityEntity>> VERITY = ENTITY_TYPES.register("verity",
            () -> EntityType.Builder.of(VerityEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 0.6f)
                    .clientTrackingRange(10)
                    .build("verity"));
}
