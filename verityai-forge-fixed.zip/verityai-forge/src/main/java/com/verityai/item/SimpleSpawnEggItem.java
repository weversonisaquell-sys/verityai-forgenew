package com.verityai.item;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.function.Supplier;

/**
 * Ovo de spawn simples para entidades que estendem LivingEntity mas não
 * Mob (ex.: BoxEntity). O ForgeSpawnEggItem exige
 * Supplier<? extends EntityType<? extends Mob>>, o que não compila para
 * essas entidades. Esta classe reimplementa o comportamento básico de
 * "clicar em um bloco para spawnar a entidade" sem essa restrição de tipo.
 */
public class SimpleSpawnEggItem extends Item {

    private final Supplier<? extends EntityType<? extends LivingEntity>> type;

    public SimpleSpawnEggItem(Supplier<? extends EntityType<? extends LivingEntity>> type, Properties properties) {
        super(properties);
        this.type = type;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        BlockPos clickedPos = context.getClickedPos();
        BlockState blockState = level.getBlockState(clickedPos);
        BlockPos spawnPos = blockState.getCollisionShape(level, clickedPos).isEmpty()
                ? clickedPos
                : clickedPos.relative(context.getClickedFace());

        EntityType<? extends LivingEntity> entityType = this.type.get();
        LivingEntity entity = entityType.create(serverLevel);
        if (entity == null) {
            return InteractionResult.FAIL;
        }

        entity.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, 0.0F, 0.0F);
        serverLevel.addFreshEntity(entity);

        context.getItemInHand().shrink(1);
        return InteractionResult.SUCCESS;
    }
}
