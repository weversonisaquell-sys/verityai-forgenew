package com.verityai.item;

import com.verityai.client.item.VeritySphereItemRenderer;
import com.verityai.entity.ModEntities;
import com.verityai.entity.VerityEntity;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/**
 * Item que guarda a Verity "capturada" (veja VerityEntity#mobInteract -
 * Shift + clique nela). Usar esse item num bloco solta ela de novo no
 * mundo, igual o mecanismo "Carry It Or Set It Down" do mod original.
 */
public class VerityBallItem extends Item {

    // Só é usado no lado cliente; instanciado sob demanda (lazy).
    private static VeritySphereItemRenderer renderer;

    public VerityBallItem(Properties properties) {
        super(properties);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) {
                    renderer = new VeritySphereItemRenderer();
                }
                return renderer;
            }
        });
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!level.isClientSide) {
            BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
            VerityEntity verity = ModEntities.VERITY.get().create(level);
            if (verity != null) {
                verity.moveTo(pos.getX() + 0.5, pos.getY() + 0.2, pos.getZ() + 0.5,
                        context.getPlayer() != null ? context.getPlayer().getYRot() : 0.0F, 0.0F);
                level.addFreshEntity(verity);

                if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
                    context.getItemInHand().shrink(1);
                }
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
