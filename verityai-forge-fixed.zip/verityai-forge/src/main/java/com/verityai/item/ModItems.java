package com.verityai.item;

import com.verityai.VerityAIMod;
import com.verityai.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VerityAIMod.MOD_ID);

    /** Ovo de spawn da Verity: aparece como uma esfera 3D de verdade (ver VeritySpawnEggItem#initializeClient). */
    public static final RegistryObject<Item> VERITY_SPAWN_EGG = ITEMS.register("verity_spawn_egg",
            () -> new VeritySpawnEggItem(ModEntities.VERITY, 0xFFD21E, 0x2B2B2B, new Item.Properties()));

    /** Bola que guarda a Verity "capturada" (Shift + clique nela). Use num bloco pra soltar de novo. */
    public static final RegistryObject<Item> VERITY_BALL = ITEMS.register("verity_ball",
            () -> new VerityBallItem(new Item.Properties().stacksTo(1)));

    /** Lanterna: clique direito liga/desliga. Enquanto ligada, dá visão noturna e afasta a escuridão pesada. */
    public static final RegistryObject<Item> VERITY_FLASHLIGHT = ITEMS.register("verity_flashlight",
            () -> new FlashlightItem(new Item.Properties().stacksTo(1)));
}
