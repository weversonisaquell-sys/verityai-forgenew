package com.verityai.item;

import com.verityai.VerityAIMod;
import com.verityai.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VerityAIMod.MOD_ID);

    /** Ovo de spawn da Verity: aparece como uma esfera 3D de verdade (ver VeritySpawnEggItem#initializeClient).
     *  Também é o item que você recebe ao capturar a Verity (VerityEntity#mobInteract). */
    public static final RegistryObject<Item> VERITY_SPAWN_EGG = ITEMS.register("verity_spawn_egg",
            () -> new VeritySpawnEggItem(ModEntities.VERITY, 0xFFD21E, 0x2B2B2B, new Item.Properties()));

    /** Lanterna: clique direito liga/desliga. Enquanto ligada, dá visão noturna e afasta a escuridão pesada. */
    public static final RegistryObject<Item> VERITY_FLASHLIGHT = ITEMS.register("verity_flashlight",
            () -> new FlashlightItem(new Item.Properties().stacksTo(1)));

    /** Ovo de spawn da caixinha 3D da Verity. */
    public static final RegistryObject<Item> BOX_SPAWN_EGG = ITEMS.register("box_spawn_egg",
            () -> new SimpleSpawnEggItem(ModEntities.BOX, new Item.Properties()));
}
