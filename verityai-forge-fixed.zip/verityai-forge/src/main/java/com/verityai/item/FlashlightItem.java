package com.verityai.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Lanterna da Verity: clique com botão direito liga/desliga. Enquanto
 * ligada, o jogador enxerga no escuro (ver FlashlightEffectHandler) e a
 * escuridão pesada da noite (ver NightDarknessOverlay, só cliente) é
 * desativada.
 */
public class FlashlightItem extends Item {
    private static final String TAG_ACTIVE = "VerityFlashlightActive";

    public FlashlightItem(Properties properties) {
        super(properties);
    }

    public static boolean isActive(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() instanceof FlashlightItem
                && stack.getOrCreateTag().getBoolean(TAG_ACTIVE);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        CompoundTag tag = stack.getOrCreateTag();
        boolean newState = !tag.getBoolean(TAG_ACTIVE);
        tag.putBoolean(TAG_ACTIVE, newState);

        level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK,
                SoundSource.PLAYERS, 0.7F, newState ? 1.4F : 1.0F);

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
