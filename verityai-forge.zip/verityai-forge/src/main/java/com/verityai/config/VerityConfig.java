package com.verityai.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class VerityConfig {
    public static final ForgeConfigSpec CLIENT_SPEC;
    private static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    private static final ForgeConfigSpec.ConfigValue<String> MODEL;
    private static final ForgeConfigSpec.ConfigValue<String> STT_MODEL;
    private static final ForgeConfigSpec.ConfigValue<String> TTS_MODEL;
    private static final ForgeConfigSpec.ConfigValue<String> TTS_VOICE;
    private static final ForgeConfigSpec.BooleanValue TTS_ENABLED;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("groq");
        API_KEY = builder
                .comment("Sua API key da Groq (crie gratis, sem cartao, em https://console.groq.com/keys)",
                         "A chave sempre comeca com \"gsk_\".",
                         "Voce tambem pode setar com o comando /verityai key <SUA_KEY> dentro do jogo.")
                .define("apiKey", "");
        MODEL = builder
                .comment("Modelo da Groq usado para gerar as respostas de texto.",
                         "Opcoes: llama-3.3-70b-versatile (melhor qualidade) ou",
                         "llama-3.1-8b-instant (mais rapido/leve, bom se bater limite de uso).")
                .define("model", "llama-3.3-70b-versatile");
        STT_MODEL = builder
                .comment("Modelo usado para transcrever sua voz (fala -> texto) quando voce",
                         "aperta a tecla V pra falar com a Verity pelo microfone.")
                .define("sttModel", "whisper-large-v3-turbo");
        TTS_ENABLED = builder
                .comment("Se true, a Verity fala em voz alta (voz de menina) tanto quando",
                         "voce conversa por microfone quanto por chat digitado.")
                .define("ttsEnabled", true);
        TTS_MODEL = builder
                .comment("Modelo de texto-para-fala da Groq.")
                .define("ttsModel", "playai-tts");
        TTS_VOICE = builder
                .comment("Voz usada pela Verity (vozes femininas disponiveis na Groq PlayAI TTS):",
                         "Celeste-PlayAI, Arista-PlayAI, Cheyenne-PlayAI, Deedee-PlayAI, Gail-PlayAI.")
                .define("ttsVoice", "Celeste-PlayAI");
        builder.pop();
        CLIENT_SPEC = builder.build();
    }

    // permite setar em runtime via comando, sem precisar reiniciar o jogo
    private static String runtimeApiKeyOverride = null;

    public static String getApiKey() {
        if (runtimeApiKeyOverride != null && !runtimeApiKeyOverride.isBlank()) {
            return runtimeApiKeyOverride;
        }
        return API_KEY.get();
    }

    public static void setApiKey(String key) {
        runtimeApiKeyOverride = key;
        API_KEY.set(key);
        API_KEY.save();
    }

    public static String getModel() {
        String m = MODEL.get();
        return (m == null || m.isBlank()) ? "llama-3.3-70b-versatile" : m;
    }

    public static String getSttModel() {
        String m = STT_MODEL.get();
        return (m == null || m.isBlank()) ? "whisper-large-v3-turbo" : m;
    }

    public static boolean isTtsEnabled() {
        return TTS_ENABLED.get();
    }

    public static String getTtsModel() {
        String m = TTS_MODEL.get();
        return (m == null || m.isBlank()) ? "playai-tts" : m;
    }

    public static String getTtsVoice() {
        String v = TTS_VOICE.get();
        return (v == null || v.isBlank()) ? "Celeste-PlayAI" : v;
    }
}
