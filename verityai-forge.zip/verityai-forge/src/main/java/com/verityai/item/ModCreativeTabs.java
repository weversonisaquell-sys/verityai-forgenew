package com.verityai.item;

import com.verityai.VerityAIMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VerityAIMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> VERITY_TAB = CREATIVE_TABS.register("verity_tab",
            () -> CreativeModeTab.builder()
                    .icon(() -> new ItemStack(ModItems.VERITY_SPAWN_EGG.get()))
                    .title(Component.translatable("itemGroup.verityai"))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.VERITY_SPAWN_EGG.get());
                        output.accept(ModItems.VERITY_ORB.get());
                        output.accept(ModItems.VERITY_FLASHLIGHT.get());
                    })
                    .build());
}
