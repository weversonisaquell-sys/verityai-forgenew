package com.verityai.item;

import com.verityai.VerityAIMod;
import com.verityai.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VerityAIMod.MOD_ID);

    /** Ovo de spawn da Verity: amarelo (cor dela) com detalhes escuros, igual os ovos vanilla. */
    public static final RegistryObject<Item> VERITY_SPAWN_EGG = ITEMS.register("verity_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VERITY, 0xFFD21E, 0x2B2B2B, new Item.Properties()));

    /** Orbe usado pra capturar a Verity (interagir com ela no mundo) e soltá-la de volta. */
    public static final RegistryObject<Item> VERITY_ORB = ITEMS.register("verity_orb",
            () -> new VerityOrbItem(new Item.Properties().stacksTo(16)));

    /** Lanterna da Verity: clique direito pra ligar/desligar uma luz que acompanha a mira. */
    public static final RegistryObject<Item> VERITY_FLASHLIGHT = ITEMS.register("verity_flashlight",
            () -> new FlashlightItem(new Item.Properties().stacksTo(1)));

    public static ItemStack createFilledVerityOrb() {
        ItemStack stack = new ItemStack(VERITY_ORB.get());
        stack.getOrCreateTag().putBoolean("Filled", true);
        return stack;
    }
}
