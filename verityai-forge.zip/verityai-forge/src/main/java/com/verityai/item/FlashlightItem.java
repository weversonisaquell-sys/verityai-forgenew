package com.verityai.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Lanterna da Verity. Clique direito liga/desliga. Enquanto ligada (tag
 * "On" = true na stack), o FlashlightManager (server tick) cuida de
 * colocar/tirar um bloco de luz invisível na direção que você está
 * olhando, e o NightDarknessOverlay (client) deixa a tela bem mais
 * escura à noite quando ela está desligada - igual o mod original.
 */
public class FlashlightItem extends Item {

    public FlashlightItem(Properties properties) {
        super(properties);
    }

    public static boolean isOn(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean("On");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean nowOn = !isOn(stack);
        stack.getOrCreateTag().putBoolean("On", nowOn);

        player.displayClientMessage(
                Component.translatable(nowOn ? "gui.verityai.flashlight.on" : "gui.verityai.flashlight.off"),
                true);
        level.playSound(null, player.blockPosition(),
                net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_GENERIC, net.minecraft.sounds.SoundSource.PLAYERS,
                0.5F, nowOn ? 1.4F : 1.0F);

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(isOn(stack) ? "gui.verityai.flashlight.on_tooltip" : "gui.verityai.flashlight.off_tooltip"));
    }
}
