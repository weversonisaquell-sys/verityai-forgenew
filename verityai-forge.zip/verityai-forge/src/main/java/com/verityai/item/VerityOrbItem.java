package com.verityai.item;

import com.verityai.entity.ModEntities;
import com.verityai.entity.VerityEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

import java.util.List;

/**
 * Orbe da Verity. Quando ela é "capturada" (interagida no mundo, veja
 * VerityEntity#mobInteract) você recebe uma stack desse item com a tag
 * "Filled" = true. Clicando com o item na mão (com esse orbe cheio) ela
 * é solta de novo na sua frente, igual usar um balde de peixe.
 */
public class VerityOrbItem extends Item {

    public VerityOrbItem(Properties properties) {
        super(properties);
    }

    private boolean isFilled(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean("Filled");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isFilled(stack)) {
            return InteractionResultHolder.pass(stack);
        }

        if (!level.isClientSide) {
            HitResult hit = player.pick(5.0D, 0.0F, false);
            net.minecraft.world.phys.Vec3 spawnPos = hit.getLocation();

            EntityType<VerityEntity> type = ModEntities.VERITY.get();
            VerityEntity verity = type.create(level);
            if (verity != null) {
                verity.moveTo(spawnPos.x, spawnPos.y + 0.5, spawnPos.z, player.getYRot(), 0.0F);
                level.addFreshEntity(verity);
                stack.shrink(1);
                player.displayClientMessage(Component.translatable("gui.verityai.capture.release"), true);
            }
        }

        player.swing(hand, true);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        if (isFilled(stack)) {
            tooltip.add(Component.translatable("gui.verityai.orb.filled_tooltip").withStyle(s -> s.withItalic(true)));
        } else {
            tooltip.add(Component.translatable("gui.verityai.orb.empty_tooltip").withStyle(s -> s.withItalic(true)));
        }
    }
}
