package com.verityai.flashlight;

import com.verityai.VerityAIMod;
import com.verityai.item.FlashlightItem;
import com.verityai.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Faz a lanterna "iluminar de verdade" sem precisar de shaders: usa o
 * bloco vanilla invisível "minecraft:light" (existe desde 1.17) com
 * nível de luz 15, colocado no bloco de ar pra onde o jogador está
 * olhando, e vai movendo esse bloco conforme o jogador se move/olha
 * pra outro lugar. Só coloca em blocos que já eram AR (nunca substitui
 * blocos reais de construção), e sempre restaura o ar de volta quando a
 * luz se move ou é desligada - não deixa "lixo" no mundo.
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID)
public class FlashlightManager {

    private static final Map<UUID, BlockPos> ACTIVE_LIGHTS = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 4 != 0) return; // não precisa recalcular todo tick

        ItemStack flashlight = findFlashlight(player);
        boolean shouldBeOn = flashlight != null && FlashlightItem.isOn(flashlight);

        if (!shouldBeOn) {
            clearLight(player);
            return;
        }

        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        BlockPos target = BlockPos.containing(eye.add(look.scale(3.0)));

        BlockPos previous = ACTIVE_LIGHTS.get(player.getUUID());
        if (previous != null && previous.equals(target)) return; // já está lá

        if (previous != null) {
            restoreIfLight(level, previous);
        }

        BlockState existing = level.getBlockState(target);
        if (existing.isAir()) {
            BlockState light = Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 15);
            level.setBlock(target, light, 3 | 16); // flag 16 = sem re-render pesado de vizinhos
            ACTIVE_LIGHTS.put(player.getUUID(), target);
        } else {
            ACTIVE_LIGHTS.remove(player.getUUID());
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        clearLight(event.getEntity());
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof Player player) {
            clearLight(player);
        }
    }

    private static void clearLight(Player player) {
        BlockPos previous = ACTIVE_LIGHTS.remove(player.getUUID());
        if (previous != null && player.level() instanceof ServerLevel level) {
            restoreIfLight(level, previous);
        }
    }

    private static void restoreIfLight(ServerLevel level, BlockPos pos) {
        if (level.getBlockState(pos).is(Blocks.LIGHT)) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3 | 16);
        }
    }

    /** Só conta como "ligada" se estiver numa das mãos (não basta estar na mochila). */
    private static ItemStack findFlashlight(Player player) {
        ItemStack main = player.getMainHandItem();
        if (main.is(ModItems.VERITY_FLASHLIGHT.get())) return main;
        ItemStack offhand = player.getOffhandItem();
        if (offhand.is(ModItems.VERITY_FLASHLIGHT.get())) return offhand;
        return null;
    }
}
