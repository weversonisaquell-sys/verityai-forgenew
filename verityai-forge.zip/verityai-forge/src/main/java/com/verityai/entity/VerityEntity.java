package com.verityai.entity;

import com.verityai.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Entidade base da Verity: uma bolinha flutuante (o visual - uma esfera
 * de verdade, gerada em código - está em
 * client/render/VerityRenderer.java, e a textura em
 * assets/verityai/textures/entity/verity.png).
 *
 * IMPORTANTE (fix de movimento): antes, a Verity era um PathfinderMob
 * "de chão" normal (com gravidade, navegação terrestre) e só o
 * DESENHO dela flutuava (efeito só visual, no renderer). Isso causava
 * o bug de "voar estranho": a hitbox/colisão andava rente ao chão, mas
 * a esfera desenhada ficava ~0.45 blocos acima dela sempre - então ao
 * subir escada, cair de um bloco, etc., dava a impressão de flutuação
 * quicada/errada. Agora ela é de verdade um mob voador (sem gravidade,
 * navegação por ar, controle de movimento suave tipo morcego/phantom),
 * igual o comportamento do mod original: ela flutua e se move
 * suavemente pelo ar, sem cair nem quicar.
 */
public class VerityEntity extends PathfinderMob {

    public VerityEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired(); // não despawna sozinha
        this.setNoGravity(true);
        this.moveControl = new FlyingMoveControl(this, 5, true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FLYING_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanFloat(true);
        return navigation;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new VerityHoverGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, net.minecraft.world.damagesource.DamageSource source) {
        return false; // ela voa, nunca deveria tomar dano de queda
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, net.minecraft.world.level.block.state.BlockState state, BlockPos pos) {
        // no-op: mob voador, ignora completamente a lógica de queda
    }

    @Override
    public void travel(Vec3 travelVector) {
        // movimento livre pelo ar (mesma lógica usada por morcego/phantom),
        // sem aplicar gravidade em nenhum eixo
        if (this.isControlledByLocalInstance()) {
            this.setSpeed((float) this.getAttributeValue(Attributes.FLYING_SPEED));
            super.travel(travelVector);
        } else {
            this.calculateEntityAnimation(false);
        }
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    /**
     * Interagir (botão direito) agora CAPTURA a Verity: ela some do mundo
     * e vira um item (Orbe da Verity) no seu inventário, igual pegar um
     * bichinho num balde. Pra conversar com ela, use a tecla V (agora
     * liga o microfone) ou digite "Verity <mensagem>" no chat - não
     * precisa mais dela estar solta no mundo pra isso.
     */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }

        ItemStack orb = ModItems.createFilledVerityOrb();
        boolean added = player.getInventory().add(orb);
        if (!added) {
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("gui.verityai.capture.full"), true);
            return InteractionResult.FAIL;
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 0.6F, 1.6F);
        if (this.level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.PORTAL, this.getX(), this.getY() + 0.3, this.getZ(), 20, 0.2, 0.3, 0.2, 0.05);
        }
        this.discard();
        return InteractionResult.CONSUME;
    }

    /**
     * Goal simples de flutuação livre: escolhe pontos aleatórios no ar
     * (não precisa ser em cima de chão) e desliza suavemente até eles,
     * igual um "fantasminha". Baseado no mesmo princípio do movimento
     * aleatório do Vex, mas com aceleração suave via MoveControl em vez
     * de velocidade instantânea (por isso não fica mais "estranho").
     */
    private static class VerityHoverGoal extends Goal {
        private final VerityEntity verity;
        private double targetX, targetY, targetZ;
        private int cooldown;

        VerityHoverGoal(VerityEntity verity) {
            this.verity = verity;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return cooldown-- <= 0;
        }

        @Override
        public boolean canContinueToUse() {
            return cooldown > 0;
        }

        @Override
        public void start() {
            pickNewTarget();
            cooldown = 40 + verity.getRandom().nextInt(60);
        }

        @Override
        public void tick() {
            verity.getMoveControl().setWantedPosition(targetX, targetY, targetZ, 0.6D);
        }

        private void pickNewTarget() {
            var random = verity.getRandom();
            targetX = verity.getX() + (random.nextDouble() * 2.0 - 1.0) * 6.0;
            targetY = verity.getY() + (random.nextDouble() * 2.0 - 1.0) * 3.0;
            targetZ = verity.getZ() + (random.nextDouble() * 2.0 - 1.0) * 6.0;
            // mantém uma altura confortável, nem debaixo do chão nem muito no céu
            targetY = Mth.clamp(targetY, verity.level().getMinBuildHeight() + 2, verity.level().getMaxBuildHeight() - 2);
        }
    }
}
