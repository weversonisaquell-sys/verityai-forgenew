package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.ai.GroqService;
import com.verityai.ai.VoiceService;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.sound.sampled.LineUnavailableException;
import java.util.Locale;

/**
 * Escuta a tecla V (Forge bus, roda todo tick no cliente). Agora, em vez
 * de abrir uma tela de chat, ela LIGA O MICROFONE: aperta uma vez pra
 * começar a gravar, aperta de novo pra parar e enviar sua fala pra
 * Verity (que transcreve, responde, e fala de volta com voz de menina).
 * Se o microfone não estiver disponível no aparelho, cai automaticamente
 * pro chat de texto normal (`Verity <mensagem>`).
 *
 * Também escuta o chat normal do Minecraft: se a mensagem começar com
 * "Verity", em vez de mandar pro servidor/mundo, ela é interceptada e
 * enviada pra IA (e a resposta também é falada em voz alta).
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class ClientForgeEvents {

    private static final String TRIGGER_WORD = "verity";
    private static final MicrophoneRecorder RECORDER = new MicrophoneRecorder();

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        while (KeyBindings.TALK_KEY.consumeClick()) {
            if (mc.player == null) continue;
            toggleMicrophone(mc);
        }
    }

    private static void toggleMicrophone(Minecraft mc) {
        if (RECORDER.isRecording()) {
            byte[] wav = RECORDER.stopAndGetWav();
            setActionBar(mc, Component.translatable("gui.verityai.voice.processing"));

            if (wav.length == 0) {
                setActionBar(mc, Component.translatable("gui.verityai.voice.empty"));
                return;
            }

            VoiceService.INSTANCE.transcribeAsync(wav,
                    text -> mc.execute(() -> {
                        if (text == null || text.isBlank()) {
                            setActionBar(mc, Component.translatable("gui.verityai.voice.empty"));
                            return;
                        }
                        addChatLine(mc, Component.literal("§b" + playerName(mc) + " (voz): §f" + text));
                        sendToVerity(mc, text);
                    }),
                    error -> mc.execute(() -> setActionBar(mc, Component.translatable("gui.verityai.voice.error"))));
        } else {
            try {
                RECORDER.start();
                setActionBar(mc, Component.translatable("gui.verityai.voice.listening"));
            } catch (LineUnavailableException | RuntimeException e) {
                VerityAIMod.LOGGER.warn("Microfone indisponível neste aparelho, usando chat de texto", e);
                setActionBar(mc, Component.translatable("gui.verityai.voice.mic_unavailable"));
                mc.setScreen(new com.verityai.client.gui.VerityChatScreen());
            }
        }
    }

    /**
     * Intercepta o chat vanilla. Digitando "Verity <mensagem>" (ou
     * "Verity: <mensagem>") no chat normal, a mensagem NÃO é enviada pro
     * mundo/servidor - ela vai direto pra IA, e a resposta aparece no
     * próprio chat E é falada em voz alta.
     */
    @SubscribeEvent
    public static void onClientChat(ClientChatEvent event) {
        String raw = event.getMessage().trim();
        if (raw.length() < TRIGGER_WORD.length()) return;

        String lower = raw.toLowerCase(Locale.ROOT);
        if (!lower.startsWith(TRIGGER_WORD)) return;

        if (raw.length() > TRIGGER_WORD.length()
                && Character.isLetterOrDigit(raw.charAt(TRIGGER_WORD.length()))) {
            return;
        }

        event.setCanceled(true);

        String rest = raw.substring(TRIGGER_WORD.length()).trim();
        if (rest.startsWith(":")) rest = rest.substring(1).trim();

        Minecraft mc = Minecraft.getInstance();
        if (rest.isEmpty()) {
            addChatLine(mc, Component.literal("§7Digite: Verity <sua mensagem>"));
            return;
        }

        addChatLine(mc, Component.literal("§b" + playerName(mc) + ": §f" + rest));
        sendToVerity(mc, rest);
    }

    /** Ponto único que fala com a IA e trata a resposta (texto no chat + voz), usado tanto pelo microfone quanto pelo chat digitado. */
    private static void sendToVerity(Minecraft mc, String message) {
        GroqService.INSTANCE.sendMessageAsync(message,
                response -> mc.execute(() -> {
                    String cleanText = com.verityai.ai.ItemRequestParser.process(response);
                    addChatLine(mc, Component.literal("§d[Verity] §f" + cleanText));
                    VoiceService.INSTANCE.speakAsync(cleanText, null, error ->
                            VerityAIMod.LOGGER.warn("Verity não conseguiu falar em voz alta: " + error));
                }),
                error -> mc.execute(() -> {
                    if ("no_key".equals(error)) {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.no_key"));
                    } else {
                        addChatLine(mc, Component.translatable("gui.verityai.chat.error", error));
                    }
                })
        );
    }

    private static String playerName(Minecraft mc) {
        return mc.player != null ? mc.player.getName().getString() : "Você";
    }

    private static void addChatLine(Minecraft mc, Component component) {
        if (mc.gui != null) {
            mc.gui.getChat().addMessage(component);
        }
    }

    private static void setActionBar(Minecraft mc, Component component) {
        if (mc.gui != null) {
            mc.gui.setOverlayMessage(component, false);
        }
    }
}
