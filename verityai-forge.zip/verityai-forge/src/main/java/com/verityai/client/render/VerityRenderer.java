package com.verityai.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.verityai.VerityAIMod;
import com.verityai.entity.VerityEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Desenha a Verity como uma ESFERA DE VERDADE, gerada matematicamente
 * (não é um cubo do Blockbench). Isso porque o formato de entidade padrão
 * do Minecraft/Forge só suporta caixas retas - pra ficar redondo de
 * verdade, a forma é montada aqui direto em código, triângulo por
 * triângulo, tipo uma bola de futebol de baixo poligonagem.
 *
 * A textura usada é a mesma "assets/verityai/textures/entity/verity.png"
 * (retangular, mapeamento tipo mapa-múndi: eixo X = longitude, eixo Y =
 * latitude). Se você fizer uma textura nova no Blockbench/editor de
 * imagem, mantém esse tipo de mapeamento equiretangular.
 */
public class VerityRenderer extends EntityRenderer<VerityEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VerityAIMod.MOD_ID, "textures/entity/verity.png");

    private static final int LAT_SEGMENTS = 12;   // "fatias" de cima a baixo
    private static final int LON_SEGMENTS = 16;   // "fatias" ao redor
    private static final float RADIUS = 0.3F;     // raio em blocos (~0.6 bloco de diâmetro)

    public VerityRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.35F;
    }

    @Override
    public ResourceLocation getTextureLocation(VerityEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(VerityEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                        MultiBufferSource bufferSource, int packedLight) {
        poseStack.pushPose();

        double bob = Math.sin((entity.tickCount + partialTicks) * 0.1) * 0.05;
        poseStack.translate(0.0, RADIUS + 0.15 + bob, 0.0);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));

        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        drawSphere(poseStack, consumer, packedLight);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, bufferSource, packedLight);
    }

    private void drawSphere(PoseStack poseStack, VertexConsumer consumer, int packedLight) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f positionMatrix = pose.pose();
        Matrix3f normalMatrix = pose.normal();

        for (int lat = 0; lat < LAT_SEGMENTS; lat++) {
            float theta1 = (float) (Math.PI * lat / LAT_SEGMENTS);
            float theta2 = (float) (Math.PI * (lat + 1) / LAT_SEGMENTS);
            float v1 = (float) lat / LAT_SEGMENTS;
            float v2 = (float) (lat + 1) / LAT_SEGMENTS;

            for (int lon = 0; lon < LON_SEGMENTS; lon++) {
                float phi1 = (float) (2 * Math.PI * lon / LON_SEGMENTS);
                float phi2 = (float) (2 * Math.PI * (lon + 1) / LON_SEGMENTS);
                float u1 = (float) lon / LON_SEGMENTS;
                float u2 = (float) (lon + 1) / LON_SEGMENTS;

                float[] p1 = toCartesian(theta1, phi1);
                float[] p2 = toCartesian(theta2, phi1);
                float[] p3 = toCartesian(theta2, phi2);
                float[] p4 = toCartesian(theta1, phi2);

                vertex(consumer, positionMatrix, normalMatrix, p1, u1, v1, packedLight);
                vertex(consumer, positionMatrix, normalMatrix, p2, u1, v2, packedLight);
                vertex(consumer, positionMatrix, normalMatrix, p3, u2, v2, packedLight);
                vertex(consumer, positionMatrix, normalMatrix, p4, u2, v1, packedLight);
            }
        }
    }

    private float[] toCartesian(float theta, float phi) {
        float x = RADIUS * (float) (Math.sin(theta) * Math.cos(phi));
        float y = RADIUS * (float) Math.cos(theta);
        float z = RADIUS * (float) (Math.sin(theta) * Math.sin(phi));
        return new float[]{x, y, z};
    }

    private void vertex(VertexConsumer consumer, Matrix4f positionMatrix, Matrix3f normalMatrix,
                         float[] p, float u, float v, int packedLight) {
        float nx = p[0] / RADIUS;
        float ny = p[1] / RADIUS;
        float nz = p[2] / RADIUS;
        consumer.vertex(positionMatrix, p[0], p[1], p[2])
                .color(255, 255, 255, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(normalMatrix, nx, ny, nz)
                .endVertex();
    }
}
