package com.verityai.client;

import com.verityai.VerityAIMod;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Grava áudio do microfone usando a API padrão do Java (javax.sound.sampled).
 *
 * ATENÇÃO IMPORTANTE: essa API é a de JVM "desktop" comum. O jogo, pelo
 * PojavLauncher no Android, roda numa JVM portada pra celular - e nem
 * toda distribuição dela expõe um mixer de gravação (TargetDataLine)
 * ligado ao microfone físico do aparelho. Se não expuser, startRecording()
 * vai lançar LineUnavailableException e o chamador (ClientForgeEvents)
 * cai automaticamente de volta pro chat digitado, com um aviso na tela.
 * Ou seja: testamos o melhor caminho possível, mas se o microfone não
 * funcionar no seu celular, não é bug do mod - é limitação do runtime
 * Java do PojavLauncher nesse aparelho/build específico.
 */
public class MicrophoneRecorder {

    private static final AudioFormat FORMAT = new AudioFormat(16000f, 16, 1, true, false);

    private TargetDataLine line;
    private ByteArrayOutputStream buffer;
    private Thread captureThread;
    private volatile boolean recording;

    public boolean isRecording() {
        return recording;
    }

    /** @throws LineUnavailableException se o dispositivo não tiver microfone acessível pela JVM. */
    public void start() throws LineUnavailableException {
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
        if (!AudioSystem.isLineSupported(info)) {
            throw new LineUnavailableException("Nenhum microfone disponível para a JVM (TargetDataLine não suportada)");
        }
        line = (TargetDataLine) AudioSystem.getLine(info);
        line.open(FORMAT);
        line.start();

        buffer = new ByteArrayOutputStream();
        recording = true;

        captureThread = new Thread(() -> {
            byte[] chunk = new byte[2048];
            while (recording && line.isOpen()) {
                int read = line.read(chunk, 0, chunk.length);
                if (read > 0) {
                    synchronized (buffer) {
                        buffer.write(chunk, 0, read);
                    }
                }
            }
        }, "verityai-mic-capture");
        captureThread.setDaemon(true);
        captureThread.start();
    }

    /** Para a gravação e devolve os bytes de um arquivo WAV pronto pra enviar pra transcrição. */
    public byte[] stopAndGetWav() {
        recording = false;
        if (line != null) {
            line.stop();
            line.close();
        }
        try {
            if (captureThread != null) captureThread.join(500);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }

        byte[] pcm;
        synchronized (buffer) {
            pcm = buffer != null ? buffer.toByteArray() : new byte[0];
        }
        if (pcm.length == 0) return new byte[0];

        try (ByteArrayOutputStream wavOut = new ByteArrayOutputStream()) {
            AudioInputStream ais = new AudioInputStream(new ByteArrayInputStream(pcm), FORMAT,
                    pcm.length / FORMAT.getFrameSize());
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, wavOut);
            return wavOut.toByteArray();
        } catch (IOException e) {
            VerityAIMod.LOGGER.warn("Falha ao empacotar áudio gravado em WAV", e);
            return new byte[0];
        }
    }
}
