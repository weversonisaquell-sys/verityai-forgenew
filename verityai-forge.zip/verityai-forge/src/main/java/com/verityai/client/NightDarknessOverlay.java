package com.verityai.client;

import com.verityai.VerityAIMod;
import com.verityai.item.FlashlightItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Escurece bastante a tela de noite, igual o clima de terror do mod
 * original. Não é uma mudança "de verdade" na luz do mundo (isso
 * exigiria reescrever o motor de luz do Minecraft) - é uma cortina
 * escura desenhada por cima de tudo, que fica quase transparente de
 * dia e bem escura de noite. Se a lanterna da Verity estiver ligada
 * na sua mão, a cortina fica bem mais fraca (você "enxerga" com a
 * lanterna).
 */
@Mod.EventBusSubscriber(modid = VerityAIMod.MOD_ID, value = Dist.CLIENT)
public class NightDarknessOverlay {

    // horário vanilla (0-24000) em que a noite é considerada "cheia"
    private static final long NIGHT_START = 13000;
    private static final long NIGHT_FULL = 14500;
    private static final long NIGHT_END_FULL = 21500;
    private static final long NIGHT_END = 23000;

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Pre event) {
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.HELMET.id())) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;

        float darkness = nightFactor(mc.level.getDayTime() % 24000L);
        if (darkness <= 0f) return;

        if (isFlashlightOn(player)) {
            darkness *= 0.25f; // com a lanterna ligada, escurece muito menos
        }

        int maxAlpha = 235;
        int alpha = (int) (darkness * maxAlpha);
        if (alpha <= 0) return;

        int color = (alpha << 24); // preto com alpha variável
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        event.getGuiGraphics().fill(0, 0, width, height, color);
    }

    private static boolean isFlashlightOn(LocalPlayer player) {
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        return FlashlightItem.isOn(main) || FlashlightItem.isOn(off);
    }

    /** Retorna 0.0 (dia) a 1.0 (noite cheia), com transição suave no anoitecer/amanhecer. */
    private static float nightFactor(long dayTime) {
        if (dayTime < NIGHT_START || dayTime > NIGHT_END) return 0f;
        if (dayTime >= NIGHT_FULL && dayTime <= NIGHT_END_FULL) return 1f;
        if (dayTime < NIGHT_FULL) {
            return (dayTime - NIGHT_START) / (float) (NIGHT_FULL - NIGHT_START);
        }
        return (NIGHT_END - dayTime) / (float) (NIGHT_END - NIGHT_END_FULL);
    }
}
