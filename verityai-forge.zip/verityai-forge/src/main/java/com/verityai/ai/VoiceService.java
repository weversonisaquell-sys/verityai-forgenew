package com.verityai.ai;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verityai.VerityAIMod;
import com.verityai.config.VerityConfig;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Fala e escuta pela Verity, usando os endpoints de áudio da Groq:
 * - speech-to-text (whisper): transcreve o que você gravou no microfone
 * - text-to-speech (playai-tts): gera a voz da Verity (voz de menina,
 *   configurável em VerityConfig.getTtsVoice())
 *
 * Igual ao GroqService, mas pra áudio. Reaproveita a mesma API key (a
 * mesma "gsk_..." que você configura com /verityai key).
 */
public class VoiceService {

    public static final VoiceService INSTANCE = new VoiceService();

    private static final String STT_ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions";
    private static final String TTS_ENDPOINT = "https://api.groq.com/openai/v1/audio/speech";

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private Clip currentClip;

    /** Manda o WAV gravado pra Groq transcrever (fala -> texto). */
    public void transcribeAsync(byte[] wavBytes, Consumer<String> onSuccess, Consumer<String> onError) {
        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            onError.accept("no_key");
            return;
        }
        if (wavBytes == null || wavBytes.length == 0) {
            onError.accept("empty_audio");
            return;
        }

        String boundary = "verityai-" + UUID.randomUUID();
        byte[] body = buildMultipartBody(boundary, wavBytes, VerityConfig.getSttModel());

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(STT_ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(body))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode() + ": " + trim(response.body()));
                }
                JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                return root.has("text") ? root.get("text").getAsString().trim() : "";
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((text, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao transcrever áudio na Groq", throwable);
                onError.accept(throwable.getCause() != null ? throwable.getCause().getMessage() : throwable.getMessage());
            } else {
                onSuccess.accept(text);
            }
        });
    }

    /** Gera a fala da Verity (texto -> áudio) e já toca no aparelho. */
    public void speakAsync(String text, Runnable onDone, Consumer<String> onError) {
        if (!VerityConfig.isTtsEnabled() || text == null || text.isBlank()) {
            if (onDone != null) onDone.run();
            return;
        }
        String apiKey = VerityConfig.getApiKey();
        if (apiKey == null || apiKey.isBlank()) {
            if (onDone != null) onDone.run();
            return;
        }

        JsonObject payload = new JsonObject();
        payload.addProperty("model", VerityConfig.getTtsModel());
        payload.addProperty("input", text);
        payload.addProperty("voice", VerityConfig.getTtsVoice());
        payload.addProperty("response_format", "wav");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TTS_ENDPOINT))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(payload.toString(), StandardCharsets.UTF_8))
                .build();

        CompletableFuture.supplyAsync(() -> {
            try {
                HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
                if (response.statusCode() / 100 != 2) {
                    throw new RuntimeException("HTTP " + response.statusCode());
                }
                return response.body();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).whenComplete((audio, throwable) -> {
            if (throwable != null) {
                VerityAIMod.LOGGER.warn("Falha ao gerar voz (TTS) na Groq", throwable);
                if (onError != null) {
                    onError.accept(throwable.getCause() != null ? throwable.getCause().getMessage() : throwable.getMessage());
                }
                if (onDone != null) onDone.run();
            } else {
                playWav(audio, onDone, onError);
            }
        });
    }

    /**
     * Toca o áudio via javax.sound.sampled. Mesma ressalva do
     * MicrophoneRecorder: no PojavLauncher/Android isso depende do
     * runtime Java expor um mixer de saída de áudio pra JVM (o jogo em
     * si toca som via OpenAL/LWJGL, não por essa API) - se não expor,
     * isso falha silenciosamente e só o texto aparece no chat.
     */
    private void playWav(byte[] wavBytes, Runnable onDone, Consumer<String> onError) {
        try {
            if (currentClip != null && currentClip.isOpen()) {
                currentClip.stop();
                currentClip.close();
            }
            AudioInputStream ais = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wavBytes));
            currentClip = AudioSystem.getClip();
            currentClip.open(ais);
            currentClip.addLineListener(event -> {
                if (event.getType() == javax.sound.sampled.LineEvent.Type.STOP) {
                    currentClip.close();
                    if (onDone != null) onDone.run();
                }
            });
            currentClip.start();
        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
            VerityAIMod.LOGGER.warn("Não foi possível tocar a voz da Verity neste aparelho", e);
            if (onError != null) onError.accept("playback_unavailable");
            if (onDone != null) onDone.run();
        }
    }

    private byte[] buildMultipartBody(String boundary, byte[] wavBytes, String model) {
        String header =
                "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"model\"\r\n\r\n"
                + model + "\r\n"
                + "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n"
                + "Content-Type: audio/wav\r\n\r\n";
        String footer = "\r\n--" + boundary + "--\r\n";

        byte[] headerBytes = header.getBytes(StandardCharsets.UTF_8);
        byte[] footerBytes = footer.getBytes(StandardCharsets.UTF_8);

        byte[] out = new byte[headerBytes.length + wavBytes.length + footerBytes.length];
        System.arraycopy(headerBytes, 0, out, 0, headerBytes.length);
        System.arraycopy(wavBytes, 0, out, headerBytes.length, wavBytes.length);
        System.arraycopy(footerBytes, 0, out, headerBytes.length + wavBytes.length, footerBytes.length);
        return out;
    }

    private String trim(String s) {
        if (s == null) return "";
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }
}
